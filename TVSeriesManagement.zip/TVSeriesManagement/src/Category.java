
public class Category {
	public Category(int id, String name) {
		this.id = id;
		this.name = name;
	}

	int id;
	String name;

}


