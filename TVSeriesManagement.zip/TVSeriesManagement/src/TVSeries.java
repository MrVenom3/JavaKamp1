
public class TVSeries {
	public TVSeries(int id, String name, String type, int year,double imdb) {
	this.id = id;
	this.name = name;
	this.type = type;
	this.year = year;
	this.imdb = imdb;
}

int id;
String name;
String type;
int year;
double imdb;

}



